"""
Hash the data from the given file and outputs MD5 hash value
"""

import hashlib
import os
import re


class DataHasher:
    def __init__(self):
        pass

    @staticmethod
    def create_hash(path_to_file, filename):
        hash_obj = hashlib.md5()
        with open(os.path.join(path_to_file, filename), "rb") as f:
            file_content = f.read()
            hash_obj.update(file_content)
            return hash_obj.hexdigest()

    def verify_hash(self, path_to_file, filename):
        hash_value = self.create_hash(path_to_file, filename)
        reg_hash_value = self.extract_hash(filename)
        if reg_hash_value == hash_value:
            return True

        return False

    @staticmethod
    def extract_hash(filename):
        pattern = r'data_([a-fA-F0-9]{32})'
        match = re.search(pattern, filename)
        if match:
            return match.group(1)
        return None

    @staticmethod
    def create_hash_from_dataframe(df):
        hash_obj = hashlib.md5()
        df_bytes = df.to_csv(index=False, lineterminator='\n').encode('utf-8')
        hash_obj.update(df_bytes)
        hash_value = hash_obj.hexdigest()
        return hash_value
